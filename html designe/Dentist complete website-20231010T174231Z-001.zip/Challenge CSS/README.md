Police d'ecriture Montserrat
https://fonts.google.com/specimen/Montserrat?query=monts

Police d'ecriture Abril
https://fonts.google.com/specimen/Abril+Fatface?query=abril&sidebar.open&selection.family=Abril+Fatface

Couleurs utilisées:

blanc: **#fff**
blanc transparent: **#FFFFFFDF**
vert clair: **#ADD981**

Flaticon utilisés:

icon scroll vers le bas : **fas-fa-angle-down**
icon de magasin : **fas fa-store**
icon retrait sans contact : **fas fa-people-carry**
icon livraison : **faq fa-truck**

Lien integration flaticon : 
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css



